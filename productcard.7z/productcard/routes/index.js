const router = require('express').Router();
const apikeyMiddleware = require('../middlewares/apiKey')


router.get('/', (req, res)=>{
    res.render("index", {
        title:"Home page"
    })
});
router.get('/about', (req, res)=>{
    res.render("about", {
        title:"about"
    })
})
router.get('/api/products', apikeyMiddleware, (req, res)=>{
    res.json([
        {
            id:"123",
            name:"shirt"
        },
        {
            id:"456",
            name:"Pent"
        }
    ])
})

module.exports = router;