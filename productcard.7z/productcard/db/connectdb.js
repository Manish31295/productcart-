const MongoClient = require("mongodb").MongoClient;

const connectDB = async (port)=>{
    try{
        const DB_OPTION = {
            nameDB = "productCart"
        }
        await MongoClient.connect(port, DB_OPTION);
        console.log('connected successfully');
    }catch(error){
        console.log(error)
    }

}
module.exports=connectDB;