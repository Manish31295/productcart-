const express = require('express');
const app = express();
const path = require('path')
const mainRouter = require('./routes/index')
const productRouter = require('./routes/products')
const port = process.env.PORT || "3001"; 


app.set('view engine', 'ejs');
app.use(express.static('public'))
app.use(mainRouter)
app.use(productRouter)
app.listen(port, ()=>{console.log(`server running on http://localhost:${port}`)});